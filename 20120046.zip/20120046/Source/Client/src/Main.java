import Model.QueueResponse;
import View.MainFrame;

public class Main {
    public static void main(String[] args) {
        new MainFrame();
    }
}
