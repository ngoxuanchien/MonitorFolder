package Model;

public class DefineString {
    public static final String COMPUTERS = "COMPUTERS";
    public static final String FOLDERS = "FOLDERS";
    public static final String NOTIFICATIONS = "NOTIFICATIONS";
    public static final String HISTORY = "HISTORY";
    public static final String MONITORFOLDER = "MONITORFOLDER";
    public static final String INFORMATION = "INFORMATION";

}
