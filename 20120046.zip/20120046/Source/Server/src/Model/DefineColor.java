package Model;

public class DefineColor {
    public static final String DARK_BLUE = "#0C5776";
    public static final String LIGHT_BLUE = "#3376BC";
    public static final String BLUE = "#91BBE5";
}
